package com.i2i.telecom.service1;

import com.i2i.telecom.model.CallEvent;
import com.i2i.telecom.model.CustomerDB;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CallController {

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public CallController(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @PostMapping("/authorize-call")
    public String authorizeCall(@RequestParam String msisdn,
                                @RequestParam String destination,
                                @RequestParam(defaultValue = "false") boolean isInternational,
                                @RequestParam int duration,
                                Model model) {

        if (!CustomerDB.balances.containsKey(msisdn)) {
            CallEvent event = new CallEvent(msisdn, destination, isInternational, duration, "FAILED", "SUBSCRIBER_NOT_FOUND");
            kafkaTemplate.send("telecom-charging-logs", msisdn, event);
            
            model.addAttribute("status", "FAILED");
            model.addAttribute("message", "Subscriber not found.");
            return "index";
        }

        int currentBalance = CustomerDB.balances.get(msisdn);
        boolean isIntAllowed = CustomerDB.internationalAllowed.get(msisdn);

        if (currentBalance <= 0) {
            CallEvent event = new CallEvent(msisdn, destination, isInternational, duration, "FAILED", "INSUFFICIENT_BALANCE");
            kafkaTemplate.send("telecom-charging-logs", msisdn, event);

            model.addAttribute("status", "FAILED");
            model.addAttribute("message", "Insufficient balance. Call blocked.");
            return "index";
        }

        if (isInternational && !isIntAllowed) {
            CallEvent event = new CallEvent(msisdn, destination, isInternational, duration, "FAILED", "INTERNATIONAL_BARRED");
            kafkaTemplate.send("telecom-charging-logs", msisdn, event);

            model.addAttribute("status", "FAILED");
            model.addAttribute("message", "International calls are barred for this subscriber.");
            return "index";
        }

        CallEvent event = new CallEvent(msisdn, destination, isInternational, duration, "SUCCESS", "NONE");
        kafkaTemplate.send("telecom-charging-logs", msisdn, event);

        model.addAttribute("status", "SUCCESS");
        model.addAttribute("message", "Call authorized successfully. Event streamed to Kafka.");
        return "index";
    }
}